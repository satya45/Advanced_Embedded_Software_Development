#include "temp.h"
#include "i2c.h"

float read_temp()
{
    temp = i2c_read();
    return temp;
}
