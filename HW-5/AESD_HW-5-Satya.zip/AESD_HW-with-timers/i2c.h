#ifndef I2C_H
#define I2C_H

#include "driverlib/gpio.h"
#include "driverlib/i2c.h"
#include "driverlib/sysctl.h"
#include "driverlib/pin_map.h"
#include "inc/hw_i2c.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_gpio.h"
#include <stdint.h>
#include <stdbool.h>


void i2c_init(void);
void i2c_write(uint8_t);
uint32_t i2c_read(void);
uint32_t clock_set;
#endif
