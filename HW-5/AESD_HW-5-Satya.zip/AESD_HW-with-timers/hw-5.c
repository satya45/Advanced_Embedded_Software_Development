//*****************************************************************************
//
// freertos_demo.c - Simple FreeRTOS example.
//
// Copyright (c) 2012-2017 Texas Instruments Incorporated.  All rights reserved.
// Software License Agreement
// 
// Texas Instruments (TI) is supplying this software for use solely and
// exclusively on TI's microcontroller products. The software is owned by
// TI and/or its suppliers, and is protected under applicable copyright
// laws. You may not combine this software with "viral" open-source
// software in order to form a larger program.
// 
// THIS SOFTWARE IS PROVIDED "AS IS" AND WITH ALL FAULTS.
// NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. TI SHALL NOT, UNDER ANY
// CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
// DAMAGES, FOR ANY REASON WHATSOEVER.
// 
// This is part of revision 2.1.4.178 of the EK-TM4C123GXL Firmware Package.
//
//*****************************************************************************

/******I2C part referred from******
 * REFERENCE:- https://www.digikey.com/eewiki/display/microcontroller/I2C+Communication+with+the+TI+Tiva+TM4C123GXL?utm_adgroup=General&slid=&gclid=CjwKCAjwqLblBRBYEiwAV3pCJkMbxl4H7FugUlooiPnYF9XRgeRsh6duOSXQjkrjcHyOWmR_uK2gsxoCj3oQAvD_BwE*/


#include "hw_timer.h"
#include "FreeRTOSConfig.h"
#include <stdbool.h>
#include <stdio.h>
#include <stdint.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "inc/hw_i2c.h"
#include "driverlib/debug.h"
#include "driverlib/gpio.h"
#include "driverlib/i2c.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/sysctl.h"
#include "driverlib/systick.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include "driverlib/fpu.h"
#include "driverlib/interrupt.h"
#include "driverlib/timer.h"
#include <time.h>
#include "timers.h"
#include "i2c.h"
#include "temp.h"

#define printf UARTprintf
#define TEMP_THRESHOLD (24)

uint32_t g_ui32Flags;
struct tm timestamp;
SemaphoreHandle_t xsemaphore,xsemaphore1,xsemaphore2, uartsem;
QueueHandle_t Q1;
TickType_t time1, time2;
char *print_str;
TaskHandle_t alert,temperature;
//*****************************************************************************
//
//! \addtogroup example_list
//! <h1>FreeRTOS Example (freertos_demo)</h1>
//!
//! This application demonstrates the use of FreeRTOS on Launchpad.
//!
//! The application blinks the user-selected LED at a user-selected frequency.
//! To select the LED press the left button and to select the frequency press
//! the right button.  The UART outputs the application status at 115,200 baud,
//! 8-n-1 mode.
//!
//! This application utilizes FreeRTOS to perform the tasks in a concurrent
//! fashion.  The following tasks are created:
//!
//! - An LED task, which blinks the user-selected on-board LED at a
//!   user-selected rate (changed via the buttons).
//!
//! - A Switch task, which monitors the buttons pressed and passes the
//!   information to LED task.
//!
//! In addition to the tasks, this application also uses the following FreeRTOS
//! resources:
//!
//! - A Queue to enable information transfer between tasks.
//!
//! - A Semaphore to guard the resource, UART, from access by multiple tasks at
//!   the same time.
//!
//! - A non-blocking FreeRTOS Delay to put the tasks in blocked state when they
//!   have nothing to do.
//!
//! For additional details on FreeRTOS, refer to the FreeRTOS web page at:
//! http://www.freertos.org/
//
//*****************************************************************************


//*****************************************************************************
//
// The mutex that protects concurrent access of UART from multiple tasks.
//
//*****************************************************************************
xSemaphoreHandle g_pUARTSemaphore;

//*****************************************************************************
//
// The error routine that is called if the driver library encounters an error.
//
//*****************************************************************************
#ifdef DEBUG
void
__error__(char *pcFilename, uint32_t ui32Line)
{
}

#endif

//*****************************************************************************
//
// This hook is called by FreeRTOS when an stack overflow error is detected.
//
//*****************************************************************************
void
vApplicationStackOverflowHook(xTaskHandle *pxTask, char *pcTaskName)
{
    //
    // This function can not return, so loop forever.  Interrupts are disabled
    // on entry to this function, so no processor interrupts will interrupt
    // this loop.
    //
    while(1)
    {
    }
}

//*****************************************************************************
//
// Configure the UART and its pins.  This must be called before UARTprintf().
//
//*****************************************************************************
void
ConfigureUART(void)
{
    //
    // Enable the GPIO Peripheral used by the UART.
    //
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    //
    // Enable UART0
    //
    ROM_SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);

    //
    // Configure GPIO Pins for UART mode.
    //
    ROM_GPIOPinConfigure(GPIO_PA0_U0RX);
    ROM_GPIOPinConfigure(GPIO_PA1_U0TX);
    ROM_GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    //
    // Use the internal 16MHz oscillator as the UART clock source.
    //
    UARTClockSourceSet(UART0_BASE, UART_CLOCK_PIOSC);

    //
    // Initialize the UART for console I/O.
    //
    UARTStdioConfig(0, 115200, 16000000);
}

/*Temperature structure*/
struct temp_data
{
    uint8_t id;
    float temp;
    uint32_t timestamp;
};

/*Led Structure*/
struct led_data
{
    uint8_t id;
    uint32_t toggle_count;
    uint32_t timestamp;
    char *name;
};


/*Common structure for led and temperature*/
typedef struct{
    uint8_t id;
    struct temp_data temp_obj;
    struct led_data led_obj;
}common_struct;

/*Interrupt handler for timer 0, configured for Temperature sensor
 * Posts semaphore frequency 1Hz
 * */
void
Timer0IntHandler(void)
{
    ROM_IntMasterDisable();
    ROM_TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    taskENTER_CRITICAL();
    if(xSemaphoreGive(xsemaphore1) != pdTRUE)
    {
        printf("Semaphore give failed in the timer handler\n");
    }
    taskEXIT_CRITICAL();
    ROM_IntMasterEnable();
}

/*Interrupt handler for timer1- Configured for LED
 * Posts semaphore frequency - 10Hz
 *
 * */
void
Timer1IntHandler(void)
{
    ROM_IntMasterDisable();
    ROM_TimerIntClear(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
    taskENTER_CRITICAL();
    if(xSemaphoreGive(xsemaphore) != pdTRUE)
    {
        printf("Semaphore give failed in the timer handler\n");
    }
    taskEXIT_CRITICAL();
    ROM_IntMasterEnable();
}

/*Led Task which takes the semaphore, toggles led and sends the structure using Queues*/
void led_task(void *param)
{
    common_struct data;
    data.led_obj.toggle_count = 0;
    data.led_obj.name = "Satya";
    while(1)
    {
        if(xSemaphoreTake(xsemaphore,portMAX_DELAY)!= pdPASS)
        {
            printf("Semaphore take faled in task\n");
        }
        GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_0, 1);
        GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_1, 0);
        data.id = 1;
        data.led_obj.toggle_count++;
        data.led_obj.timestamp = xTaskGetTickCount();
        if(xQueueSend(Q1,(void*)&data,(TickType_t)10)!= pdPASS)
        {
            printf("Failed to send message in led task1\n");
        }
        if(xSemaphoreTake(xsemaphore,portMAX_DELAY)!= pdPASS)
        {
            printf("Semaphore take failed in task\n");
        }
        GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_0, 0);
        GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_1, 2);
        data.id = 1;
        data.led_obj.toggle_count++;
        data.led_obj.timestamp = xTaskGetTickCount(); //Get timestamp
        /*Mutex to protect sending via queue*/
        if(xSemaphoreTake(xsemaphore2,portMAX_DELAY)!= pdPASS)
        {
            printf("Mutex take failed in task\n");
        }
        if(xQueueSend(Q1,(void*)&data,(TickType_t)10)!=pdPASS) //Wait for 10 ticks if the Queue is full.
        {
            printf("Failed to send message in led task 2\n");
        }
        if(xSemaphoreGive(xsemaphore2)!= pdPASS)
        {
            printf("Mutex give failed in task\n");
        }
    }
}

/*Temperature task which reads the temperature and populates the structure and sends the structure using Queues*/
void temp_task(void *param)
{
    common_struct data;
    data.id = 0;
    while(1)
    {
        if(xSemaphoreTake(xsemaphore1,portMAX_DELAY)!= pdPASS)
        {
            printf("Semaphore take failed in task\n");
        }
        data.id = 0;
        time2 = xTaskGetTickCount();
        data.temp_obj.timestamp = (uint32_t)time2;
        data.temp_obj.temp = read_temp();
        if(data.temp_obj.temp >= TEMP_THRESHOLD)
        {
            xTaskNotifyGive(alert);
        }
        /*Mutex to protect sending via Queue*/
        if(xSemaphoreTake(xsemaphore2,portMAX_DELAY)!= pdPASS)
        {
            printf("Mutex take failed in task\n");
        }
        if(xQueueSend(Q1,(void*)&data,(TickType_t)10)!= pdPASS)
        {
            printf("Failed to send message in temp task1\n");
        }
        if(xSemaphoreGive(xsemaphore2)!= pdPASS)
        {
            printf("Mutex give failed in task\n");
        }
    }
}

/*Logger task, receives from the Queue and prints on the UART*/
void log_task(void *param)
{
    common_struct rcvd_data;
    while(1)
    {
        if(xQueueReceive(Q1, &(rcvd_data), ( TickType_t )0 ) )
        {
            if(rcvd_data.id == 1)
            {
                if(xSemaphoreTake(uartsem,portMAX_DELAY)!= pdPASS)
                {
                    printf("Mutex take failed in log\n");
                }
                printf("*****LED Data Received*****\n");
                printf("LED Toggle Count %d\n",rcvd_data.led_obj.toggle_count);
                printf("My Name: %s\n", rcvd_data.led_obj.name);
                printf("Timestamp %dms\n\n", rcvd_data.led_obj.timestamp);
                if(xSemaphoreGive(uartsem)!= pdPASS)
                {
                    printf("Mutex give failed in log\n");
                }

            }
            else
            {
                if(xSemaphoreTake(uartsem,portMAX_DELAY)!= pdPASS)
                {
                    printf("Mutex take failed in alert\n");
                }
                printf("*****Temperature Data Received*****\n");
                printf("Temperature Read %d.%d C\n",(int8_t)rcvd_data.temp_obj.temp, (uint8_t)(rcvd_data.temp_obj.temp * 100));
                printf("Timestamp %dms\n\n", rcvd_data.temp_obj.timestamp);
                if(xSemaphoreGive(uartsem)!= pdPASS)
                {
                    printf("Mutex give failed in alert\n");
                }
            }
        }


    }
}

/*Alert task, waits for the notification and prints to the UART upon reception of the notification*/
void alert_task(void *param)
{
    while(1)
    {
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
        if(xSemaphoreTake(uartsem,portMAX_DELAY)!= pdPASS)
        {
            printf("Mutex take failed in alert\n");
        }
        printf("ALERT:::: Temperature beyond %d threshold\n\n", TEMP_THRESHOLD);
        if(xSemaphoreGive(uartsem)!= pdPASS)
        {
            printf("Mutex give failed in alert\n");
        }
    }
}

//*****************************************************************************
//
// Initialize FreeRTOS and start the initial set of tasks.
//
//*****************************************************************************
int
main(void)
{
    clock_set = SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ | SYSCTL_OSC_MAIN|SYSCTL_USE_PLL|SYSCTL_CFG_VCO_480), 120000000);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);
    GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_0);
    GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_1);
    xsemaphore = xSemaphoreCreateBinary(); // Led Task Semaphore
    xsemaphore1 = xSemaphoreCreateBinary(); //Temperature task Semaphore
    xsemaphore2 = xSemaphoreCreateMutex(); //Queue Mutex
    uartsem = xSemaphoreCreateMutex(); //UART Mutex

    /*Create Queue*/
    Q1 = xQueueCreate(1, sizeof(common_struct));
    if(Q1 == NULL)
    {
        printf("Queue was not created\n");
    }
    if (xsemaphore == NULL)
    {
        printf("Binary Semaphore failed");
    }
    BaseType_t t1,t2,t3,t4;
    ConfigureUART();
    i2c_init();

    /*Create tasks*/
    t1 = xTaskCreate(led_task,"LedTask", 1000, NULL, 1, NULL);
    if(t1 == pdPASS)
    {
        printf("LED Task created\n\n");
    }
    t2 = xTaskCreate(log_task,"LoggerTask", 1000, NULL, 1, NULL);
    if(t2 == pdPASS)
    {
        printf("Logger Task created\n\n");
    }
    t3 = xTaskCreate(temp_task,"TemperatureTask", 1000, NULL, 1, &temperature);
    if(t3 == pdPASS)
    {
        printf("Temperature Task created\n\n");
    }

    t4 = xTaskCreate(alert_task,"AlertTask", 1000, NULL, 1, &alert);
    if(t4 == pdPASS)
    {
        printf("Alert Task created\n\n");
    }
    timer_init();
    vTaskStartScheduler();

    vTaskDelete(led_task);
    vTaskDelete(log_task);
    vTaskDelete(temp_task);
    vTaskDelete(alert_task);

}
