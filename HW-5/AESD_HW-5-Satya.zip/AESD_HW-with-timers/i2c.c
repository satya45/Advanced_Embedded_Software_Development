#include "i2c.h"
#include "temp.h"


/*I2C Initialization for I2C 2*/
void i2c_init()
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C2);
    SysCtlPeripheralReset(SYSCTL_PERIPH_I2C2);

    GPIOPinConfigure(GPIO_PN5_I2C2SCL);
    GPIOPinConfigure(GPIO_PN4_I2C2SDA);

    GPIOPinTypeI2CSCL(GPIO_PORTN_BASE, GPIO_PIN_5);
    GPIOPinTypeI2C(GPIO_PORTN_BASE, GPIO_PIN_4);

    I2CMasterInitExpClk(I2C2_BASE, clock_set, false);
}

/*Write to the slave address
 * Slave address passed for temperature sensor
 *
 * */
void i2c_write(uint8_t reg)
{
    I2CMasterSlaveAddrSet(I2C2_BASE, SLAVE_ADDR, false); //False because we are writing to slave
    I2CMasterDataPut(I2C2_BASE, reg);
    I2CMasterControl(I2C2_BASE, I2C_MASTER_CMD_SINGLE_SEND); //we are sending single byte to pointer register
    while(!I2CMasterBusy(I2C2_BASE)); //Need to wait until busy flag is set. ERRATA I2C#08
    while(I2CMasterBusy(I2C2_BASE));
}


/*Read from I2C slave, writes pointer register to 0x00 for our application and
 * take reading from temperature sensor*/
uint32_t i2c_read(void)
{
    uint32_t data[2];
    float final_temp;
    i2c_write(TEMP_REG);
    I2CMasterSlaveAddrSet(I2C2_BASE, SLAVE_ADDR, true); //true because we are reading from slave.
    I2CMasterControl(I2C2_BASE, I2C_MASTER_CMD_BURST_RECEIVE_START);
    while(!I2CMasterBusy(I2C2_BASE)); //Wait for Busy bit to be 1 as per ERRATA
    while(I2CMasterBusy(I2C2_BASE));
    data[0] = I2CMasterDataGet(I2C2_BASE);
    I2CMasterControl(I2C2_BASE, I2C_MASTER_CMD_BURST_RECEIVE_FINISH);
    while(!I2CMasterBusy(I2C2_BASE));
    while(I2CMasterBusy(I2C2_BASE));
    data[1] = I2CMasterDataGet(I2C2_BASE);
    final_temp = (float)((data[0] << 8 | data[1]) >> 4) * 0.0625; //Temperature calculation from raw data
    return final_temp;

}
