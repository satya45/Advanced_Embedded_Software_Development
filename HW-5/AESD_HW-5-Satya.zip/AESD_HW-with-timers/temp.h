#ifndef TEMP_H
#define TEMP_H

#include <stdint.h>
#define SLAVE_ADDR 0x48
#define TEMP_REG 0x00
#define TLOW 0x02
#define THIGH 0x03

float read_temp(void);

float temp;

#endif
